/**
 * @file PortConfig.h
 * @brief The port's own settings (port.ini), separate from the engine's Settings.ini.
 *
 * Values are read once at launch. Changes made through the web page are
 * written immediately but, like uploaded saves, only take effect after the
 * game restarts.
 */
#ifndef SWM_PORT_CONFIG_H
#define SWM_PORT_CONFIG_H

#include <mutex>
#include <string>

namespace swm
{

class PortConfig
{
public:
    /** File name inside the data directory. */
    static constexpr const char *kFileName = "port.ini";

    /** Loads @p path; missing files or keys keep their defaults. */
    explicit PortConfig(std::string path);

    /**
     * Whether the Mania Plus content is enabled. Off by default, as the
     * RSDKv5 decompilation licence requires for distributed builds.
     */
    bool IsPlusEnabled() const;

    /** Stores the Plus opt-in. @return False if port.ini could not be written. */
    bool SetPlusEnabled(bool enabled);

    /**
     * Whether the retro games (Sonic 1, 2 and CD from the player's own packs,
     * see RetroGames.h) are offered in the Back menu. Off by default.
     */
    bool IsRetroEnabled() const;

    /** Stores the retro opt-in. @return False if port.ini could not be written. */
    bool SetRetroEnabled(bool enabled);

    /**
     * The game to start when the app is opened: the id of the last game that
     * was left normally ("mania", "sonic1", ...), or "" for the default.
     *
     * main() clears it while a game runs and sets it again when the game is
     * left normally, so a game that crashes on start is not started again on
     * the next launch.
     */
    std::string LastGame() const;

    /** Stores the game to start next time ("" for the default). @return False if port.ini could not be written. */
    bool SetLastGame(const std::string &id);

private:
    /** Writes the current values to disk. Caller holds mutex_. */
    bool SaveLocked() const;

    std::string path_;
    mutable std::mutex mutex_;
    bool plusEnabled_  = false;
    bool retroEnabled_ = false;
    std::string lastGame_;
};

} // namespace swm

#endif // SWM_PORT_CONFIG_H
